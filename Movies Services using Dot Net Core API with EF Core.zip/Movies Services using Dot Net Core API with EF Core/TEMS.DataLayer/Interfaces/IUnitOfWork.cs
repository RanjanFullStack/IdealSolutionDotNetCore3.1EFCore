﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.Models.LibraryModel;

namespace TEMS.DataLayer.Interfaces
{
   public interface IUnitOfWork
    {
       
        IGenericRepository<VideoLibrary> VideoLibraryRepository { get; }

        Task Save();
    }
}

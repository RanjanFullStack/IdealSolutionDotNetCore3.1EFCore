﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace TEMS.DataLayer.Interfaces
{
    public interface IConnectionFactory : IDisposable
    {

        IDbConnection GetConnection { get; }

        void CloseConnection(IDbConnection connection);

        IDbTransaction BeginTransaction(ref IDbConnection connection);
        void CommitTransaction(IDbTransaction transaction);

        void RollbackTransaction(IDbTransaction transaction);

    }
}

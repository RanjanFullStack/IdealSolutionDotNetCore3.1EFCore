﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.DatabaseContext;
using TEMS.Models.LibraryModel;

namespace TEMS.DataLayer.Repository
{
    public class UnitOfWork : IUnitOfWork, IDisposable
    {
        private readonly TEMSContext _context;
        public IGenericRepository<VideoLibrary> _videoLibraryRepository { get; set; }

        public UnitOfWork(TEMSContext context)
        {
            _context = context;
        }

        public IGenericRepository<VideoLibrary> VideoLibraryRepository
        {
            get { return _videoLibraryRepository ?? (_videoLibraryRepository = new GenericRepository<VideoLibrary>(_context)); }
        }

        public async Task Save()
        {
          await  _context.SaveChangesAsync();
        }

        private bool disposed;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed && disposing)
            {
                _context.Dispose();
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}

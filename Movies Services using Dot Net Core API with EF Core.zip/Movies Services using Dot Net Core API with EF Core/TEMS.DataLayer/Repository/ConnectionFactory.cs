﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using TEMS.DataLayer.Interfaces;

namespace TEMS.DataLayer.Repository
{
    [ExcludeFromCodeCoverage]
    public class ConnectionFactory : IConnectionFactory
    {
        private readonly string _connectionString;
        public ConnectionFactory(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IDbConnection GetConnection
        {
            get
            {
                SqlConnection connection = new SqlConnection(_connectionString);
                connection.Open();
                return connection;
            }
        }

        public IDbTransaction BeginTransaction(ref IDbConnection connection)
        {
            if (connection == null || connection.State == ConnectionState.Closed)
            {
                connection = GetConnection;
            }
            return connection.BeginTransaction(IsolationLevel.ReadUncommitted);
        }

        public void CommitTransaction(IDbTransaction transaction)
        {
            if (transaction != null)
            {
                transaction.Commit();
            }
        }

        public void RollbackTransaction(IDbTransaction transaction)
        {
            if (transaction != null && transaction.Connection != null)
            {
                transaction.Rollback();
            }
        }

        public void CloseConnection(IDbConnection connection)
        {
            if (connection != null)
            {
                connection.Close();
                connection.Dispose();
            }
        }

        #region IDisposable Support
        private bool disposedValue; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // dispose managed state (managed objects).
                }

                // free unmanaged resources (unmanaged objects) and override a finalizer below.
                // set large fields to null.

                disposedValue = true;
            }
        }

        ~ConnectionFactory()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(false);
        }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // uncomment the following line if the finalizer is overridden above.
            GC.SuppressFinalize(this);
        }


        #endregion
    }
}

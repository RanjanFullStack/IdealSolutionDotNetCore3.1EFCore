﻿using System.ComponentModel.DataAnnotations;

namespace TEMS.Models.Hepler
{
    public enum KeyEnum
    {
        
        [Display(Name = "sql-connection-endo-aesthetics")]
        SqlConnection
    }
}

﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEMS.Models.Hepler
{
    public static class Extensions
    {
        public static T CloneNonVirtualProperties<T>(this T source)
        {
            T dest = Activator.CreateInstance<T>();
            var props = typeof(T).GetProperties()
                .Where(x => x.CanWrite)
                .Where(v => !v.GetAccessors()[0].IsVirtual)
                .ToList();

            foreach (var sourceProp in props)
            {
                if (props.Any(x => x.Name == sourceProp.Name))
                {
                    var p = props.First(x => x.Name == sourceProp.Name);
                    p.SetValue(dest, sourceProp.GetValue(source, null), null);
                }
            }
            return dest;
        }

      
    }
}

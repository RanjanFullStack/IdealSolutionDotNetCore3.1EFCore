﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using TEMS.Models.LibraryModel;

namespace TEMS.Models.DatabaseContext
{
    public partial class TEMSContext : DbContext
    {
        public TEMSContext()
        {
        }

        public TEMSContext(DbContextOptions<TEMSContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            OnModelCreatingPartial(modelBuilder);
            // Map Entity names to DB Table names
            modelBuilder.Entity<VideoLibrary>().ToTable("VideoLibrary");
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

        public virtual DbSet<VideoLibrary> VideoLibrary { get; set; }
    }
}

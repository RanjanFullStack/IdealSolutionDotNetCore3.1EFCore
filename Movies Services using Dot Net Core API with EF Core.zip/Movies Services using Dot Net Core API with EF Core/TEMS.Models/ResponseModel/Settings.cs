﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.ResponseModel
{
   public class Settings
    {
        public string DatabaseConnectionString;
        public string Database;
        public string ApiBaseUrl;

        public IConfigurationRoot iconfigurationRoot;

        
    }
}

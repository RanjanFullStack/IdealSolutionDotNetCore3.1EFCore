﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.ResponseModel
{
   public class UserLoginResponseModel
    {
    }
}

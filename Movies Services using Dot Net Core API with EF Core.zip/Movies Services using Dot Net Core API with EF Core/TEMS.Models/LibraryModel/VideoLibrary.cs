﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TEMS.Models.LibraryModel
{
    public partial class VideoLibrary
    {
        public VideoLibrary()
        {

        }

        [Key]
        public int Id { get; set; }
        [StringLength(255)]
        public string Title { get; set; }
        [Column("Release Year")]
        public int? ReleaseYear { get; set; }
        [StringLength(255)]
        public string Locations { get; set; }
        [Column("Fun Facts")]
        [StringLength(4000)]
        public string FunFacts { get; set; }
        [Column("Production Company")]
        [StringLength(255)]
        public string ProductionCompany { get; set; }
        [StringLength(255)]
        public string Distributor { get; set; }
        [StringLength(255)]
        public string Director { get; set; }
        [StringLength(255)]
        public string Writer { get; set; }
        [Column("Actor 1")]
        [StringLength(255)]
        public string Actor1 { get; set; }
        [Column("Actor 2")]
        [StringLength(255)]
        public string Actor2 { get; set; }
        [Column("Actor 3")]
        [StringLength(255)]
        public string Actor3 { get; set; }
    }
}

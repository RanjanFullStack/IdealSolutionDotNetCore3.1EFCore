﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;
using TEMS.Models.Models;

namespace TEMS.Models.RequestModel
{
   public  class TopicRequestModel
    {
        public int TopicId { get; set; }
        public string TopicName { get; set; }
        public string TopicDescription { get; set; }
        public long DocumentId { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public int? UserID { get; set; }
        public DateTime? UpdatedOn { get; set; }

        [JsonIgnore]
        public virtual TblDocument Document { get; set; }
    }
}

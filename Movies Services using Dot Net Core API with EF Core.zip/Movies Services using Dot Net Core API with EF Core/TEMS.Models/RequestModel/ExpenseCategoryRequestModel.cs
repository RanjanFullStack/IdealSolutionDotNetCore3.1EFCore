﻿using System;
using System.Collections.Generic;
using System.Text;
using TEMS.Models;

namespace TEMS.Models.RequestModel
{
    public class ExpenseCategoryRequestModel
    {
        public int ExpenseCategoryId { get; set; }
        public string ExpenseCategoryName { get; set; }
        public string CategoryConstant { get; set; }
        public bool? HasHcpaccess { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int UserID { get; set; }
    }
}

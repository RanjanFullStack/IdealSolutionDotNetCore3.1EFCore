﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace TEMS.Models.RequestModel
{
   public class ForgotPasswordModel
    {
        public string EmailId { get; set; }
    }
}
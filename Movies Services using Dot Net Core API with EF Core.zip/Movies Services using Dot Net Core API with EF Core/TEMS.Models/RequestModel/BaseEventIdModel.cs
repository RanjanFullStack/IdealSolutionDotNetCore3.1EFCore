﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.RequestModel
{
   public class BaseEventIdModel
    {
        public Guid EventId { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TEMS.Models.RequestModel
{
   public enum UserCategory
    {
        [Display(Name ="HCP")]
        HCP=1,
        [Display(Name = "Trainer")]
        Trainer =2,
        [Display(Name = "User")]
        User = 3,
        [Display(Name = "admin")]
        Admin = 4
    }
}

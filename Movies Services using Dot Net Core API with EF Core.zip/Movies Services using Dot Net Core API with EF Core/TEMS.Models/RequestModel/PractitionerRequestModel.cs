﻿using System;
using System.Collections.Generic;
using System.Text;
using TEMS.Models;

namespace TEMS.Models.RequestModel
{
    public class PractitionerRequestModel
    {
        //public int PractitionerId { get; set; }
        public int UserId { get; set; }
        public string PracticeName { get; set; }
        //public string LegalName { get; set; }
        //public string Title { get; set; }
        public string Degree { get; set; }//
        public int? SpecialtyId { get; set; }//
        //public long? CvdocumentId { get; set; }
        //public long? ProfilePictureId { get; set; }

        public string Npinumber { get; set; }//
        public string StateOfLicensure { get; set; }//
        public string LicenseNumber { get; set; }//
        public string AlternateEmailId { get; set; }//


        //public string OfficePhone { get; set; }
        public string CellPhone { get; set; }//
        public string HomePhone { get; set; }//
        //public string FaxNumber { get; set; }
        //public string AssistantName { get; set; }
        //public string AssistantEmailId { get; set; }
        //public string AssistantPhone { get; set; }
        //public int PreferredContactMethodId { get; set; }
        //public string PractitionerBio { get; set; }
        public bool? IsActive { get; set; }
        //public int? CreatedBy { get; set; }
        //public DateTime? CreatedOn { get; set; }
        //public int? UpdatedBy { get; set; }
        //public DateTime? UpdatedOn { get; set; }
        //public int UserID { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.RequestModel
{
   public  class UserMealPreferenceRequestModel
    {
        public int UserMealPreferenceId { get; set; }
        public int UserId { get; set; }
        public int MealPreferenceId { get; set; }
        public int PreferenceNumber { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.RequestModel
{
    public class TimeZoneRequestModel
    {
        public int TimeZoneId { get; set; }
        public string TimeZoneName { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int  UseID { get; set; }
        //view model
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.RequestModel
{
   public class EventRequestModel
    {
        private Guid _id;

        public Guid EventId
        {
            get { if (_id == null || _id == Guid.Empty) { _id = Guid.NewGuid(); } return _id; }
            set { if (value == null || value == Guid.Empty) { value = Guid.NewGuid(); } _id = value; }
        }
        public DateTime DateTime { get; set; }
        public string SalesRep { get; set; }
        public string Planner { get; set; }
        public string Speaker { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Topic { get; set; }
        public string Format { get; set; }
        public string Venue { get; set; }
        public string Registration { get; set; }
        public string Attendees { get; set; }
    }
}

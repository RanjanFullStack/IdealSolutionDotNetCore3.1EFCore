﻿using System;
using System.Collections.Generic;
using System.Text;
using TEMS.Models.Models;

namespace TEMS.Models.RequestModel
{
    public class StateRequestModel
    {


        public int StateId { get; set; }
        public string StateName { get; set; }
        public string StateCode { get; set; }
        public int TimeZoneId { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int UserID { get; set; }
        public virtual TblTimeZone TimeZone { get; set; }


    }
}

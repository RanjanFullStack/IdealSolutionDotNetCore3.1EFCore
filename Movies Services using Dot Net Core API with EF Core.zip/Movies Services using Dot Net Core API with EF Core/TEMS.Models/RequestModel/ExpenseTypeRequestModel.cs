﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.RequestModel
{
    public class ExpenseTypeRequestModel
    {
        public int ExpenseTypeId { get; set; }
        public int ExpenseCategoryId { get; set; }
        public string ExpenseTypeName { get; set; }
        public bool? HasHcpaccess { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int UserID { get; set; }
    }
}

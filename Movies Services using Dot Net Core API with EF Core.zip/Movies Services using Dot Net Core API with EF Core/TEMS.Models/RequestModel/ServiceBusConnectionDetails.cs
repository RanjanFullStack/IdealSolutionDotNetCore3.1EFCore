﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TEMS.Models.RequestModel
{
    public class ServiceBusConnectionDetails
    {
        public string ConnectionString { get; set; }
        public string ServiceBusName { get; set; }
        public Queue Queue { get; set; }
    }

    public enum Queue
    {
        [Display(Name = "send-email")]
        sendemail,
        [Display(Name = "user-registration")]
        userregistration,
    }
}

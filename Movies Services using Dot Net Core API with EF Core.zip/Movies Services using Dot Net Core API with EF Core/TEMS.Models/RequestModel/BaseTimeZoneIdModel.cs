﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.RequestModel
{
    public class BaseTimeZoneIdModel
    {
        public Guid TimeZoneID { get; set; }
    }
}

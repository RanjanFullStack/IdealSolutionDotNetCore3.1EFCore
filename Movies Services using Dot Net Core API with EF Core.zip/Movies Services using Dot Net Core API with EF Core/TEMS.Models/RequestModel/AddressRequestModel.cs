﻿using System;
using System.Collections.Generic;
using System.Text;
using TEMS.Models.Models;

namespace TEMS.Models.RequestModel
{
   public  class AddressRequestModel
    {
        public int AddressId { get; set; }
        public int AddressTypeId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; } 
        public string AddressLine3 { get; set; }
        public string CityName { get; set; }
        public int StateId { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public virtual TblAddressType AddressType { get; set; }
        public int UserID { get; set; }
    }
}

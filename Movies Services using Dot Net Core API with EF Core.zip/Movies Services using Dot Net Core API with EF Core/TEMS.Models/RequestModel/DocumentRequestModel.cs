﻿using System;
using System.Collections.Generic;
using System.Text;
using TEMS.Models.Models;
namespace TEMS.Models.RequestModel
{
    public class DocumentRequestModel
    {
        public long DocumentId { get; set; }
        public int DocumentCategoryId { get; set; }
        public string DocumentName { get; set; }
        public string FilePath { get; set; }
        public int FileTypeId { get; set; }
        public bool? IsConfidential { get; set; }
        public bool? IsTemplate { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int UserId { get; set; }

        public virtual TblDocumentCategory DocumentCategory { get; set; }
        public virtual TblFileType FileType { get; set; }
        public virtual ICollection<TblPractitioner> TblPractitionerCvdocument { get; set; }
        public virtual ICollection<TblPractitioner> TblPractitionerProfilePicture { get; set; }
        public virtual ICollection<TblTopic> TblTopic { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.RequestModel
{
    public class TravelPreferenceRequestModel
    {
        public int TravelPreferenceId { get; set; }
        public int UserId { get; set; }
        public bool IsPreferredTravel { get; set; }
        public int GenderId { get; set; }
        public DateTime? BirthDate { get; set; }
        public string KnownTravelerId { get; set; }
        public string TsapreCheckNumber { get; set; }
        public string GlobalEntryNumber { get; set; }
        public string RedressNumber { get; set; }
        public string TravelAirport { get; set; }
        public string SeatPreference { get; set; }


        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}

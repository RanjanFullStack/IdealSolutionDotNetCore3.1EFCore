﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEMS.Models.RequestModel
{
   public class PasswordModel
    {
        public string NewPassword { get; set; }
        
        public string ConfirmPassword { get; set; }
        public string EmailId { get; set; }
    }
}

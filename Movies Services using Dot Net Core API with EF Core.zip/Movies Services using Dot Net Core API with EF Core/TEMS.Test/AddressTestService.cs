﻿using Microsoft.EntityFrameworkCore;
using System;
using TEMS.BusinessLayer.Repository;
using TEMS.DataLayer.Repository;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;
using TEMS.Services.Repository;
using Xunit;

namespace TEMS.Test
{
public class AddressTestService
{
    readonly DbContextOptions<TEMSContext> Options;





        public AddressTestService()
    {
        // Run the test against one instance of the context
        Options = new DbContextOptionsBuilder<TEMSContext>()
            .UseInMemoryDatabase(databaseName: "TEMS_Database")
            .Options;
    }
        [Fact]
        public void AddressRepository_Add_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                var addressRepository = new AddressRepository(new UnitOfWork(context));
                var address = new AddressRequestModel 
                {
                    AddressId = 1,
                    AddressLine1 = "BhavDhan,Pune1",
                    AddressLine2 = "BhavDhan,Pune2",
                    AddressLine3 = "BhavDhan,Pune2",
                    AddressTypeId = 1001,
                    CityName = "Pune",
                    Latitude = "esrSrdfggd",
                    Longitude = "gsfdfg",
                    CreatedOn = DateTime.UtcNow,
                    IsActive = true,
                    
                };
                 addressRepository.AddAddress(address);
                var userCount = context.TblUser.CountAsync().Result;
                Assert.Equal(1, userCount);
            }
        }
        [Fact]

        public void AddressRepository_Update_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                var addressRepository = new AddressRepository(new UnitOfWork(context));
                var address = new AddressRequestModel
                {
                  
                    AddressLine1 = "BhavDhan,Pune",
                    AddressLine2 = "BhavDhan,Pune",
                    AddressLine3 = "Eversana",
                    AddressTypeId = 1001,
                    CityName = "Pune",
                    Latitude = "esrSrdfggd",
                    Longitude = "gsfdfg",
                    CreatedOn = DateTime.UtcNow,
                    IsActive = true,

                };
                addressRepository.UpdateAddress(address);
                var userCount = context.TblUser.CountAsync().Result;
                Assert.Equal(1, userCount);
            } 
        }
        [Fact]

        public void AddressRepository_GetAllAddress_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                TblAddress address = new TblAddress();
                var addressRepository = new AddressRepository(new UnitOfWork(context));

               var getdata = addressRepository.GetAddressDetail();
                
            }
        }
        [Fact]

        public void AddressRepository_GetAllAddressByID_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                TblAddress address = new TblAddress();
                var addressRepository = new AddressRepository(new UnitOfWork(context));

               var getdata = addressRepository.GetByAddressID(address.AddressId);
                
            }
        }
        [Fact]

        public void AddressRepository_DeleteByID_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                TblAddress address = new TblAddress();
                var addressRepository = new AddressRepository(new UnitOfWork(context));

               var getdata = addressRepository.DeleteById(address.AddressId);
                
            }
        }
    }

    }




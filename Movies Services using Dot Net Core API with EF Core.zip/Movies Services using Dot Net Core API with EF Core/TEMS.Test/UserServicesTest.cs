﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Configuration;
using TEMS.DataLayer.Repository;
using TEMS.Models.Models;
using TEMS.Services;
using Xunit;

namespace TEMS.Test
{

    public class UserServicesTest
    {
        readonly DbContextOptions<TEMSContext> Options;
        public UserServicesTest()
        {
            // Run the test against one instance of the context
            Options = new DbContextOptionsBuilder<TEMSContext>()
               .UseInMemoryDatabase(databaseName: "TEMS_Database")
               .Options;
        }
        [Fact]
        public void UserRepository_Add_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                var userRepository = new UserServices(new UnitOfWork(context));
                var user = new TblUser
                {
                    UserId = 1,
                    UserName = "Eversana",
                    Password = "Admin@123",
                    FirstName = "Eversana",
                    MiddleName = "Eversana",
                    LastName = "Eversana",
                    CreatedBy = 1,
                    CreatedOn = DateTime.UtcNow,
                    IsActive = true,
                    IsBlocked = false,
                    IsResetPassword = false
                };
                userRepository.Add(user);
                var userCount = context.TblUser.CountAsync().Result;
                Assert.Equal(1, userCount);
            }
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using System;
using TEMS.BusinessLayer.Repository;
using TEMS.DataLayer.Repository;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;
using TEMS.Services.Repository;
using TEMS.Services.Services;
using Xunit;
namespace TEMS.Test
{
    public class TopicTestService
    {
        readonly DbContextOptions<TEMSContext> Options;
        public TopicTestService()
        {
            // Run the test against one instance of the context
            Options = new DbContextOptionsBuilder<TEMSContext>()
                .UseInMemoryDatabase(databaseName: "TEMS_Database")
                .Options;
        }
        [Fact]
        public void TopicRepository_Add_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                var TopicRepository = new TopicServices(new UnitOfWork(context));
                var Topic = new TopicRequestModel
                {
                    TopicId = 1,
                    TopicName = "BhavDhan,Pune1",
                    TopicDescription = "BhavDhan,Pune2",
                    CreatedOn = DateTime.UtcNow, 
                    IsActive = true,

                };
                TopicRepository.AddTopic(Topic);
                var userCount = context.TblUser.CountAsync().Result;
                Assert.Equal(1, userCount);
            }
        }
        [Fact]

        public void TopicRepository_Update_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                var addressRepository = new TopicServices(new UnitOfWork(context));
                var address = new TopicRequestModel
                {

                    TopicId = 1,
                    TopicName = "BhavDhan,Pune1",
                    TopicDescription = "BhavDhan,Pune2",
                    UpdatedOn = DateTime.UtcNow,
                    UpdatedBy = 1001,
                    IsActive = true,

                };
                addressRepository.UpdateTopic(address);
                var userCount = context.TblUser.CountAsync().Result;
                Assert.Equal(1, userCount);
            }
        }
        [Fact]

        public void TopicRepository_GetAllAddress_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                TblTopic address = new TblTopic();
                var topicRepository = new TopicServices(new UnitOfWork(context));

                var getdata = topicRepository.GetTopicDetail();

            }
        }
        [Fact]

        public void TopicRepository_GetAllAddressByID_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                TblTopic topic = new TblTopic();
                var topicRepository = new TopicServices(new UnitOfWork(context));

                var getdata = topicRepository.GetByTopicID(topic.TopicId);

            }
        }
        [Fact]

        public void TopicRepository_DeleteByID_ReturnSucess()
        {
            using (var context = new TEMSContext(Options))
            {
                TblTopic topic = new TblTopic();
                var topicRepository = new AddressRepository(new UnitOfWork(context));

                var getdata = topicRepository.DeleteById(topic.TopicId);

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Hosting;
using Xunit;

namespace TEMS.Test
{
    public class StartupTest
    {
        [Fact]
        public void TestStartup()
        {
            //var webHost = Microsoft.AspNetCore.WebHost.CreateDefaultBuilder().UseStartup<Startup>().Build();
            //Assert.NotNull(webHost);
        }
    }
}

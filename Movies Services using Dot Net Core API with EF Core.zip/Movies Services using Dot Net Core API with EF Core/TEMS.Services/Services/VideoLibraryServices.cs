﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using TEMS.BusinessLayer.Interfaces;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.LibraryModel;
using TEMS.DataLayer.Helper;
using System.Linq.Expressions;
using System.Linq;

namespace TEMS.Services.Services
{
    public class VideoLibraryServices : IVideoLibraryServices
    {
        private readonly IUnitOfWork _unitOfWork;
     
        public VideoLibraryServices(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<List<VideoLibrary>> Read(Expression<Func<VideoLibrary, bool>> filter = null, Func<IQueryable<VideoLibrary>, IOrderedQueryable<VideoLibrary>> orderBy = null, params Expression<Func<VideoLibrary, object>>[] includes)
        {
            var result = await _unitOfWork.VideoLibraryRepository.Read();
            return result;
        }

        public IQueryable<VideoLibrary> Query(Expression<Func<VideoLibrary, bool>> filter = null, Func<IQueryable<VideoLibrary>, IOrderedQueryable<VideoLibrary>> orderBy = null)
        {
            throw new NotImplementedException();
        }


        public ValueTask<VideoLibrary> ReadFirstOrDefault(Expression<Func<VideoLibrary, bool>> filter = null, params Expression<Func<VideoLibrary, object>>[] includes)
        {
            throw new NotImplementedException();
        }

        public async Task<int> DeleteById(object id)
        {
            var result = await _unitOfWork.VideoLibraryRepository.DeleteById(id);
            return result;
        }

        public async Task<ApiResult<VideoLibrary>> GetByFilter(int pageIndex, int pageSize, string sortColumn, string sortOrder, string filterColumn, string filterQuery)
        {
            var result = _unitOfWork.VideoLibraryRepository.Query();
            return await ApiResult<VideoLibrary>.CreateAsync(
                        result.Select(c => new VideoLibrary()
                        {
                            Id = c.Id,
                            Writer = c.Writer,
                            Actor1 = c.Actor1,
                            Actor2 = c.Actor2,
                            Actor3 = c.Actor3,
                            Director = c.Director,
                            Distributor = c.Distributor,
                            FunFacts = c.FunFacts,
                            Locations = c.Locations,
                            ProductionCompany = c.ProductionCompany,
                            ReleaseYear = c.ReleaseYear,
                            Title = c.Title
                        }),
                    pageIndex,
                    pageSize,
                    sortColumn,
                    sortOrder,
                    filterColumn,
                    filterQuery);
        }

        public async Task<bool> Add(VideoLibrary entity)
        {
            var result = await _unitOfWork.VideoLibraryRepository.Add(entity);
            return result;
        }

        public async ValueTask<VideoLibrary> ReadById(object id)
        {
            var result = await _unitOfWork.VideoLibraryRepository.ReadById((int)id);
            return result;
        }

        public async Task<bool> Update(VideoLibrary entity)
        {
            var videoFromDB = await _unitOfWork.VideoLibraryRepository.ReadById(entity.Id);

            videoFromDB.Title = entity.Title;
            videoFromDB.ReleaseYear = entity.ReleaseYear;
            videoFromDB.Locations = entity.Locations;
            videoFromDB.ProductionCompany = entity.ProductionCompany;
            videoFromDB.Distributor = entity.Distributor;
            videoFromDB.Director = entity.Director;
            videoFromDB.Writer = entity.Writer;
            videoFromDB.Actor1 = entity.Actor1;
            videoFromDB.Actor2 = entity.Actor2;
            videoFromDB.Actor3 = entity.Actor3;
            videoFromDB.FunFacts = entity.FunFacts;

            return await _unitOfWork.VideoLibraryRepository.Update(videoFromDB);
        }
    }
}

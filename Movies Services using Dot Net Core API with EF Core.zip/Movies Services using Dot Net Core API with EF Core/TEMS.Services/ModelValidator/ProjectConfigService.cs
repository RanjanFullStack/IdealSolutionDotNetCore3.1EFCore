﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Microsoft.Extensions.Options;
using TEMS.Models.ResponseModel;
using JsonConvert = Newtonsoft.Json.JsonConvert;
using TEMS.DataLayer.Interfaces;
using TEMS.DataLayer.Repository;
using Microsoft.EntityFrameworkCore;
using TEMS.Services.Helpers;
using TEMS.Models.Hepler;
using Microsoft.AspNetCore.Hosting;
using TEMS.Models.DatabaseContext;

namespace TEMS.Services.Services
{
    public class ProjectConfigService
    {
        public IConfigurationRoot Configuration;

        public ProjectConfigService(IConfigurationRoot configurationRoot)
        {
            Configuration = configurationRoot;

        }
        public  void BuildServices(IServiceCollection services,IWebHostEnvironment env)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });
            string connectionString =ConnectionHelper.GetValue(KeyEnum.SqlConnection.GetDisplayName(),env.EnvironmentName);

            services.AddTransient<IConnectionFactory>(_ => new ConnectionFactory(connectionString));
            services.AddDbContext<TEMSContext>(options => options
                                                    //.UseLazyLoadingProxies()
                                                    .UseSqlServer(connectionString));

            services.Configure<Settings>(o => { o.iconfigurationRoot = Configuration; });
            services.AddMvcCore().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            services.AddMvcCore(options =>
                {
                options.Filters.Add(typeof(ValidateModelStateAttribute));
            });
            //services.AddMvcCore().AddJsonOptions(options =>
            //{
            //    options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            //    options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            //});
        }
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TEMS.Models.ResponseModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TEMS.Services.Services
{
   public class ValidateModelStateAttribute :ActionFilterAttribute
    {
    //    public async override void OnActionExecuting(ActionExecutingContext context)
    //    {
    //        Dictionary<string, string> errorObject = new Dictionary<string, string>();
    //        if (!context.ModelState.IsValid)

    //        {
    //            foreach (var item in context.ModelState)
    //            {
    //                var itemErrorKey = item.Key;
    //                var itemErrorMessage = item.Value.Errors.FirstOrDefault().ErrorMessage;
    //                errorObject.Add(itemErrorKey, itemErrorMessage);
    //            }
    //            context.Result = new BadRequestResult(errorObject);


    //        }
    //    }
    //}
    //public class BadRequestResult : JsonResult
    //{

    //    public BadRequestResult(Dictionary<string, string> errorObject)
    //        : base(new APIPageResponseModel(false, System.Net.HttpStatusCode.BadRequest, "Invalid Input", errorObject))
    //    {
    //        StatusCode = StatusCodes.Status400BadRequest;
    //    }
    }
}

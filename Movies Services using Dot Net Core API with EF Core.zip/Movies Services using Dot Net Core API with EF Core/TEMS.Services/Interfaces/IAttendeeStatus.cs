﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
//using TEMS.Models.RequestModel;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.BusinessLayer.Interfaces
{
    public interface IAttendeeStatus
    {
        //Task<bool> AddattendeeStatus(AttendeeStatusRequestModel attendeeStatusRequestModel);
        //Task<bool> UpdateattendeeStatus(AttendeeStatusRequestModel attendeeStatusRequestModel);
        Task<List<TblAttendeeStatus>> GetAttendeeStatusDetail();

        Task<TblAttendeeStatus> GetByAttendeeStatusID(int id);
        Task<int> DeleteById(int id);
    }
}

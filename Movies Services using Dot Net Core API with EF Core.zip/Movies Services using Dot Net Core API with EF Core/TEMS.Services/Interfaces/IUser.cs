﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;
using TEMS.Models.ResponseModel;

namespace TEMS.Services.Interfaces
{
   public interface IUser
    {
        Task<int> Add(TblUser user);
        Task<TblUser> Login(LoginModel user);
        Task<bool> ResetPassword(PasswordModel passwordModel);

    }
}

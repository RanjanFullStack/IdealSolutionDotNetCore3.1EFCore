﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
//using TEMS.Models.RequestModel;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface IEvents
    {
        Task<List<Event>> GetAllEvents();
        Task<bool> AddEvent(EventRequestModel requestObject);
        Task<bool> UpdateEvent();
        Task<Event> GetEventDetail(BaseEventIdModel requestObject);
        Task<bool> SearchEvent();
        Task<bool> DeleteEvent();

    }
}
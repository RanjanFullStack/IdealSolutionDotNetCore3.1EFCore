﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface ITravelStatus
    {
        Task<List<TblTravelStatus>> GetAllTravelStatusDetails();

        Task<TblTravelStatus> GetTravelStatusByID(int id);
        Task<int> DeleteByTravelStatusID(int id);

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface  IUserMealPreference
    {
        Task<bool> AddMealPreference(UserMealPreferenceRequestModel requestObject);
        Task<bool> UpdateMealPreference(UserMealPreferenceRequestModel requestObject);
        Task<List<TblUserMealPreference>> GetMealPreferenceAllDetail();

        Task<TblUserMealPreference> GetByMealPreferenceByID(int id);
        Task<int> MealPreferenceDeleteById(int id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface  ITravelPreference
    {
        Task<bool> AddTravelPreference(TravelPreferenceRequestModel requestObject);
        Task<bool> UpdateTravelPreference(TravelPreferenceRequestModel requestObject);
        Task<List<TblTravelPreference>> GetTravelPreferenceAllDetail();

        Task<TblTravelPreference> GetByTravelPreferenceByID(int id);
        Task<int> TravelPreferenceDeleteById(int id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.Models.Models;

namespace TEMS.Services.Interfaces
{
    public interface IExpenseType
    {
        Task<List<TblExpenseType>> GetAllDetailExpenseType();

        Task<TblExpenseType> GetByExpenseTypeTypeID(int id);
        Task<int> DeleteByExpenseTypeID(int id);
    }
}

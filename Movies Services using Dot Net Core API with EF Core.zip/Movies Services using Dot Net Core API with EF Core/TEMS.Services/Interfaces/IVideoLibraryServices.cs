﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Helper;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.LibraryModel;

namespace TEMS.BusinessLayer.Interfaces
{
    public interface IVideoLibraryServices : IGenericRepository<VideoLibrary>
    {
        //Task <bool> AddVideo(VideoLibrary requestObject);
        //Task <bool> UpdateVideo(VideoLibrary requestObject);
        //Task <List<VideoLibrary>> GetAllVideos();
      
        //Task <VideoLibrary> GetVideoById(int id);
        //Task <int> DeleteById(int id);
        //Task<ApiResult<VideoLibrary>> GetVideos(int pageIndex, int pageSize, string sortColumn, string sortOrder, string filterColumn, string filterQuery);
    }
}

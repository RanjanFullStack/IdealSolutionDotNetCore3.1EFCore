﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface IVenue
    {
        Task<List<TblVenue>> GetAllVenues();
        Task<bool> AddVenue(TblVenue requestObject);
        Task<bool> UpdateVenue();
        Task<TblVenue> GetVenueDetail(int id);
        Task<bool> SearchVenue();
        Task<bool> DeleteVenue();

    }
}

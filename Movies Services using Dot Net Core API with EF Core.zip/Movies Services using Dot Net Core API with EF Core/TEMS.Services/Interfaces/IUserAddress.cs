﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface IUserAddress
    {
        Task<bool> AddUserAddress(UserAddressRequestModel requestObject);
        Task<bool> UpdateUserAddress(UserAddressRequestModel requestObject);
        Task<List<TblUserAddress>> GetUserAddressDetail();

        Task<TblUserAddress> GetByUserAddressID(int id);
        Task<int> UserDeleteById(int id);
    }
}

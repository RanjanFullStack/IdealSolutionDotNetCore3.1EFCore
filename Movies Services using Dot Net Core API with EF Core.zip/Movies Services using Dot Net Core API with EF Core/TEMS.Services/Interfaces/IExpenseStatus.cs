﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.Models.Models;

namespace TEMS.Services.Interfaces
{
   public interface IExpenseStatus
    {
        Task<List<TblExpenseStatus>> GetAllDetailExpenseStatus();

        Task<TblExpenseStatus> GetByExpenseStatusTypeID(int id);
        Task<int> DeleteByExpenseStatusID(int id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface ITopic
    {
        Task<bool> AddTopic(TopicRequestModel requestObject);
        Task<bool> UpdateTopic(TopicRequestModel requestObject);
        Task<List<TblTopic>> GetTopicDetail();

        Task<TblTopic> GetByTopicID(int id);
        Task<int> DeleteById(int id);
    }
}

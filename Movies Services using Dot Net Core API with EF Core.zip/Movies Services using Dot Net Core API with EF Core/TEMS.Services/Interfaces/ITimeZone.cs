﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
//using TEMS.Models.RequestModel;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;


namespace TEMS.BusinessLayer.Interfaces
{
    public interface ITimeZone
    {
        Task<List<TblTimeZone>> GetAllTimeZone();
   
       // Task<TblTimeZone> GetTimeZoneDetail(BaseTimeZoneIdModel requestObject);
       // Task<TblTimeZone> GetByTimeZoneID(int id);
       //Task<int> DeleteById(int id);
    }
}

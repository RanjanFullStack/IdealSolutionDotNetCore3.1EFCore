﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;
using TEMS.Models.DataModel;

namespace TEMS.Services.Interfaces
{
   public  interface IUserManage
    {
        Task<List<TblUser>> GetAllUserName();
        Task<bool> UpdateUserPhysianInfo(UserRequestModel userRequestModel);
        Task<int> UpdateProfileGeneralInformation(TblUser userDataModel);

    }
}

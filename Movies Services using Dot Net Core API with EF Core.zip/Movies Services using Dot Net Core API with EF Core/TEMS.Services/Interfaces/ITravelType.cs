﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
   public  interface ITravelType
    {
        Task<List<TblTravelType>> GetAllTravelTypeDetails();

        Task<TblTravelType> GetTravelTypeByID(int id);
        Task<int> DeleteByTravelTypeID(int id);
    }
}

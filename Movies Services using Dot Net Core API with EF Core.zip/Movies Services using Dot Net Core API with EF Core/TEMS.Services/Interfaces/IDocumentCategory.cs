﻿using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface IDocumentCategory
    {
        Task<List<TblDocumentCategory>> GetAllDetailMealStatus();

        Task<TblDocumentCategory> GetByMealStatusTypeID(int id);
        Task<int> DeleteByEventStatusID(int id);
    }
}

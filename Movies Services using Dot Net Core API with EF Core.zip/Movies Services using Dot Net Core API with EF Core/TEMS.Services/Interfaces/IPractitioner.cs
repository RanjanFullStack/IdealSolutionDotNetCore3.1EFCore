﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
   public  interface IPractitioner
    {

        Task<int> AddPractitioner(PractitionerRequestModel requestObject);
        //Task<bool> UpdatePractitioner(PractitionerRequestModel requestObject);
        //Task<List<TblPractitioner>> GetPractitionerAllDetail();

        //Task<TblPractitioner> GetByPractitionerByID(int id);
        //Task<int> PractitionerDeleteById(int id);
    }
}

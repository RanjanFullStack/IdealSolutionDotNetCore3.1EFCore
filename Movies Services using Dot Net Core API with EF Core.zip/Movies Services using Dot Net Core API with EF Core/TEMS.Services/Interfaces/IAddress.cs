﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.BusinessLayer.Interfaces
{
    public interface IAddress
    {
        Task <bool> AddAddress(AddressRequestModel requestObject);
        Task <bool> UpdateAddress(AddressRequestModel requestObject);
        Task <List<TblAddress>> GetAddressDetail();
      
        Task <TblAddress> GetByAddressID(int id);
        Task <int> DeleteById(int id);
    }
}

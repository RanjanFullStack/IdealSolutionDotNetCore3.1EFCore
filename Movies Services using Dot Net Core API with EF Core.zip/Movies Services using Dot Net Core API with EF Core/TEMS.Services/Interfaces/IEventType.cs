﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.BusinessLayer.Interfaces
{
   public  interface IEventType
    {
       //Task <bool> AddEventType(EventTypeRequestModel requestObject);
       //Task<bool> UpdateEventType(EventTypeRequestModel requestObject);
       Task <List<TblEventType>> GetEventTypeDetail();

       Task <TblEventType> GetByEventTypeID(int id);
       Task <int> DeleteById(int id);
    }
}

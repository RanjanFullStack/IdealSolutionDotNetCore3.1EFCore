﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.BusinessLayer.Interfaces
{
    public interface IEventStatus
    {
        
        Task <List<TblEventStatus>> GetAllEventStatus();

        Task <TblEventStatus> GetByEventStatusID(int id);
        Task<int> DeleteByEventStatusID(int id);
    }
}

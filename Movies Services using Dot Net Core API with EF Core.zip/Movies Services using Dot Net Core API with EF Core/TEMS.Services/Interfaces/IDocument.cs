﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface IDocument
    {
        Task<bool> AddDocument(DocumentRequestModel requestObject);
        Task<bool> UpdateDocument(DocumentRequestModel requestObject);
        Task<List<TblDocument>> GetDocumentDetail();

        Task<TblDocument> GetByDocumentID(int id);
        Task<int> DeleteById(int id);
    }
}

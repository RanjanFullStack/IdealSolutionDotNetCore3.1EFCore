﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.BusinessLayer.Interfaces
{
    public interface IState
    {
      
        Task<List<TblState>> GetStateAllDetail();

        //Task<TblState> GetByStateID(int id);
        //Task<int> DeleteById(int id);
    }
}

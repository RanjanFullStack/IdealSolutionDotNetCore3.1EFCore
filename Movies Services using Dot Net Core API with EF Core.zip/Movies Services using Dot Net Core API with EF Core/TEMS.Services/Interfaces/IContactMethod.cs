﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface IContactMethod
    {
        
        Task<List<TblContactMethod>> GetAllContactMethod();

        Task<TblContactMethod> GetByContactMethodByID(int id);
        Task<int> DeleteByContactMethodID(int id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.Services.Interfaces
{
    public interface ITrainerType
    {
     
        Task<List<TblTrainerType>> GetTrainerTypeAllDetails();

        Task<TblTrainerType> GetTrainerTypeDetailsByID(int id);
        Task<int> TrainerTypeDeleteById(int id);
    }
}

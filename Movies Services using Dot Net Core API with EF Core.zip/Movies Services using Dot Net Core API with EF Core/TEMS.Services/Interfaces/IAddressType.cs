﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TEMS.DataLayer.Interfaces;
//using TEMS.Models.RequestModel;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;

namespace TEMS.BusinessLayer.Interfaces
{
    public interface IAddressType
    {
        //Task<bool> AddTypeAddress(AddressTypeRequestModel requestObject);
        //Task<bool> UpdateAddressType(AddressTypeRequestModel requestObject);
        Task <List<TblAddressType>> GetAllAddressType();

        Task <TblAddressType> GetByAddressTypeID(int id);
        Task <int> DeleteByAddressTypeID(int id);
    }
}

﻿
using Microsoft.AspNetCore.Hosting;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;
using TEMS.Models.Hepler;

namespace TEMS.Services.Helpers
{
    public class ConnectionHelper
    {
        private static Dictionary<string, string> cache = new Dictionary<string, string>();
        private static IConfigurationRoot Configuration { get; set; }

        public static string GetValue(string key, string envName = null)
        {
            string value = GetFromCache(key);

            if (String.IsNullOrEmpty(value))
            {
                value = GetFromAppSettings(key, envName);

                if (String.IsNullOrEmpty(value))
                {
                    throw new System.NullReferenceException();
                }
                UpdteCache(key, value);
            }
            return value;

        }

        private static string GetFromCache(string key)
        {
            string value;
            cache.TryGetValue(key, out value);
            return value;
        }

        private static string GetFromAppSettings(string key, string envName)
        {
            if (Configuration == null)
                BuildConfig(envName);
            var value = Configuration.GetSection(key).Value;
            return value;
        }

        private static bool UpdteCache(string key, string value)
        {
            var ExistingKey = GetFromCache(key);
            if (string.IsNullOrEmpty(ExistingKey))
            {
                cache.Add(key, value);
                return true;
            }
            return false;
        }

        private static void BuildConfig(string envName)
        {
            var builder = new ConfigurationBuilder()
                 .SetBasePath(Directory.GetCurrentDirectory())
                 .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                 .AddJsonFile($"appsettings.{envName}.json", optional: true)
                  .AddEnvironmentVariables();
            Configuration = builder.Build();

        }
    }
}

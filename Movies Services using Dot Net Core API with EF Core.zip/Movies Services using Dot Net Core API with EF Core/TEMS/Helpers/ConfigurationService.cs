﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TEMS.Services.Services;

namespace TEMS.Helpers
{
    public class ConfigurationService
    {
        public IConfigurationRoot Configuration { get; set; }
        public IServiceCollection Services { get; set; }

        private static ConfigurationService _Instance;

        public static ConfigurationService Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new ConfigurationService();
                }
                return _Instance;
            }
        }

        private ConfigurationService()
        {

        }

        internal void BuildServices(IServiceCollection services,IWebHostEnvironment env)
        {
            ProjectConfigService projectConfigService = new ProjectConfigService(Configuration);
            projectConfigService.BuildServices(services,env);
        }
    }
}

﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TEMS.Models.Hepler;
using TEMS.Models.ResponseModel;
using TEMS.Services.Helpers;

namespace TEMS.Helpers
{
    public class URLHelper
    {
        private IOptions<Settings> _settings;
        public URLHelper(IOptions<Settings> settings)
        {
            _settings = settings;
        }
        public  Uri GetApiURL(string controllerName, string actionMethodName)
        {
            return new Uri($"{ ConnectionHelper.GetValue(KeyEnum.APIBaseURL.GetDisplayName()) }{controllerName}/{actionMethodName }");
        }
    }
}

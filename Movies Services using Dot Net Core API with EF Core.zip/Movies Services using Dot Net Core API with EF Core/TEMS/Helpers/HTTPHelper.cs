﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TEMS.Models.Hepler;
using TEMS.Models.ResponseModel;
using TEMS.Services.Helpers;

namespace TEMS.Helpers
{
    public class HTTPHelper
    {
        private IConfiguration _configuration;
        private IOptions<Settings> _settings;
        public HTTPHelper(IOptions<Settings> settings, IConfiguration configuration)
        {
            _settings = settings;
            _configuration = configuration;

        }

        public HttpClient GetHttpClient()
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.BaseAddress = (new Uri(ConnectionHelper.GetValue(KeyEnum.APIBaseURL.GetDisplayName())));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            return client;
        }

        public async Task<string> PostRequest<T>(HttpClient client, Uri url, T model)
        {
            try
            {

                client.DefaultRequestHeaders.Accept.Clear();
                Task<HttpResponseMessage> response = client.PostAsJsonAsync(url, model);
                if (response.Result.IsSuccessStatusCode)
                {
                    return await response.Result.Content.ReadAsStringAsync();
                }

                throw new HttpRequestException(" url :" + url + " model: " + model);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task<string> PostRequest(HttpClient client, Uri url)
        {
            try
            {
                client.DefaultRequestHeaders.Accept.Clear();
                Task<HttpResponseMessage> response = client.PostAsync(url, null);
                if (response.Result.IsSuccessStatusCode)
                {
                    return await response.Result.Content.ReadAsStringAsync();
                }

                throw new HttpRequestException(" url :" + url);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

     
    }
}

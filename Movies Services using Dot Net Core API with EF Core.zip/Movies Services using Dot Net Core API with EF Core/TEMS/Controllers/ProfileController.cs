﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TEMS.Models.Models;
using System.Web;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.Extensions.Options;
using TEMS.Models.ResponseModel;
using TEMS.Models.DataModel;
using TEMS.Helpers;
using Microsoft.Extensions.Configuration;
using TEMS.ViewModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using TEMS.Models.RequestModel;
using System.Collections;
using Microsoft.Azure.Amqp.Framing;
using System.Net.Http.Headers;
using TEMS.Services.Helpers;

namespace TEMS.Controllers
{
    public class ProfileController : Controller
    {

        private IConfiguration _configuration;
        private IOptions<Settings> _settings;
        private HTTPHelper _helper;
        private URLHelper _urlHelper;
        public ProfileController(IOptions<Settings> settings, IConfiguration configuration)
        {
            _settings = settings;
            _configuration = configuration;
            _helper = new HTTPHelper(_settings, _configuration);
            _urlHelper = new URLHelper(_settings);
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult GeneralProfile()
        {
            return View();
        }
        public IActionResult ProfileIndex()
        {
            return View();
        }

        public IActionResult ProfileDetails()
        {
            return View();
        }
        [HttpGet]
        public IActionResult CreateProfile(string strID)
        {
            


                ProfileViewModel PVM = new ProfileViewModel();
                //PVM.EventList = GetAllEventss();
                PVM.StateList = GetAllStates();
                PVM.ListValueMaster = GetAllSpecialty();
                PVM.TimeZoneList = GetAllTimeZone();
              


                //     ViewBag.spaecialMastList = spaecialMastList;
                return View(PVM);
            
           

        }
       [HttpPost]
   public IActionResult CreateProfile(ProfileViewModel profileViewModel)
        {
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();


            // ArrayList paramList = new ArrayList();

            #region Practitioner
            var practitionerData = new PractitionerRequestModel
            {

                SpecialtyId = profileViewModel.SpecialtyId,
                UserId = 2,
                Degree = profileViewModel.Degree,
                CellPhone = profileViewModel.CellPhone,
                HomePhone = profileViewModel.HomePhone,
                PracticeName = profileViewModel.PracticeName,
                Npinumber = profileViewModel.Npinumber,
                StateOfLicensure = profileViewModel.StateOfLicensure,
                LicenseNumber = profileViewModel.LicenseNumber,
                AlternateEmailId = profileViewModel.ProfileEmailId,
                IsActive = true,
            };
            #endregion


            #region  Address Data 
            var addressData = new TblAddress
            {
                AddressLine1 = profileViewModel.AddressLine1,
                CityName = profileViewModel.CityName,
                StateId = profileViewModel.StateId,
            };
            #endregion

            
            #region  TblUser

            var userData = new TblUser
            {
                FirstName = profileViewModel.FirstName,
                MiddleName = profileViewModel.MiddleName,
                LastName = profileViewModel.LastName,
                SoldToMcKessonId = profileViewModel.SoldToMcKessonId,
                EmailId = profileViewModel.ProfileEmailId,
            };
            #endregion

            Uri apiURLPract = _urlHelper.GetApiURL("Practioner", "AddPractionerInfo");
            var requestURLPract = _helper.PostRequest(Client, apiURLPract, practitionerData);

            Uri apiURLUser = _urlHelper.GetApiURL("Profile", "AddPractionerInfo");
            Uri apiURLUserAddress = _urlHelper.GetApiURL("Address", "AddPracticeInfo");

            var requestURLAddress = _helper.PostRequest(Client, apiURLPract, addressData);
           // var requestURLPract = _helper.PostRequest(Client, apiURLUserAddress, practitionerData);


            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURLPract.Result);
            if (response.isSuccess)
            {

                View();
            }
            else
            {
                //Error response received 
                // profileViewModel = Enumerable.Empty<ProfileViewModel>();
                ModelState.AddModelError(string.Empty, "Server error try after some time.");
            }

            return View();

        }



        #region Populate Data from Master table
        public List<TblState> GetAllStates()
        {

            //var list = new List<TEMS.Models.Models.TblState>();

            Uri apiURLState = _urlHelper.GetApiURL("State", "GetAllStates");
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();
            var requestURL = _helper.PostRequest(Client, apiURLState);
            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            var events = JsonConvert.DeserializeObject<List<TblState>>(Convert.ToString(response.data));

            List<TblState> List = new List<TblState>();
            foreach (var x in events)
            {
                List.Add(new TblState()
                {
                    StateName = x.StateName,
                    StateId = x.StateId
                });
            }
            return List;

        }

        public List<Event> GetAllEventss()
        {


            Uri apiURLState = _urlHelper.GetApiURL("Event", "GetAllEvents");
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();
            var requestURL = _helper.PostRequest(Client, apiURLState);
            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            var events = JsonConvert.DeserializeObject<List<Event>>(Convert.ToString(response.data));

            List<Event> List = new List<Event>();
            foreach (var x in events)
            {
                List.Add(new Event()
                {
                    State = x.State,
                    Id = x.Id
                });
            }
            return List;

        }
        public List<TblListValue> GetAllSpecialty()
        {


            Uri apiURLState = _urlHelper.GetApiURL("ListValue", "GetAllSpecialtyList");
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();
            var requestURL = _helper.PostRequest(Client, apiURLState);
            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            var events = JsonConvert.DeserializeObject<List<TblListValue>>(Convert.ToString(response.data));

            List<TblListValue> List = new List<TblListValue>();
            foreach (var x in events)
            {
                List.Add(new TblListValue()
                {
                    ListValueName = x.ListValueName,
                    ListValueId = x.ListValueId
                });
            }
            return List;

        }
        public List<TblTimeZone> GetAllTimeZone()
        {

            //var list = new List<TEMS.Models.Models.TblState>();

            Uri apiURLState = _urlHelper.GetApiURL("TimeZone", "GetAllTimeZone");
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();
            var requestURL = _helper.PostRequest(Client, apiURLState);
            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            var TimeZone = JsonConvert.DeserializeObject<List<TblTimeZone>>(Convert.ToString(response.data));

            List<TblTimeZone> List = new List<TblTimeZone>();
            foreach (var x in TimeZone)
            {
                List.Add(new TblTimeZone()
                {
                    TimeZoneName = x.TimeZoneName,
                    TimeZoneId = x.TimeZoneId
                });
            }
            return List;

        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TEMS.Services.Helpers;
using TEMS.Models.ResponseModel;
using System.Net.Http;
using System.Net.Http.Headers;
using TEMS.BusinessLayer.Interfaces;
using TEMS.Models.LibraryModel;

namespace TEMS.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class VideoLibraryController : ControllerBase
    {
        private IVideoLibraryServices _videoLibraryServcies;
        public VideoLibraryController(IVideoLibraryServices videoLibraryServcies)
        {
            _videoLibraryServcies = videoLibraryServcies;
        }
        #region ActionMethods

        [HttpGet]
        public async Task<ResponseModel> GetAllVideos()
        {
            try
            {
                var result = await _videoLibraryServcies.Read();
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {

                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }

        // GET: api/Cities
        // GET: api/Cities/?pageIndex=0&pageSize=10
        // GET: api/Cities/?pageIndex=0&pageSize=10&sortColumn=name&sortOrder=asc
        // GET: api/Cities/?pageIndex=0&pageSize=10&sortColumn=name&sortOrder=asc&filterColumn=name&filterQuery=york
        [HttpGet]
        public async Task<ResponseModel> GetVideos(
                int pageIndex = 0,
                int pageSize = 10,
                string sortColumn = null,
                string sortOrder = null,
                string filterColumn = null,
                string filterQuery = null)
        {
            try
            {
                var result = await _videoLibraryServcies.GetByFilter(pageIndex, pageSize, sortColumn, sortOrder, filterColumn,filterQuery);

                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {

                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }
        }

        [HttpGet]
        public async Task<ResponseModel> GetVideoById(int id) 
        {
            try
            {
                var result = await _videoLibraryServcies.ReadById(id);
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }

        [HttpPost]
        public async Task<ResponseModel> AddVideo([FromBody] VideoLibrary requestObject)
        {
            try
            {
                return (await _videoLibraryServcies.Add(requestObject)) ? APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.BadRequest);

            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }

        [HttpPost]
        public async Task<ResponseModel> UpdateVideo([FromBody] VideoLibrary requestObject)
        {
            try
            {
                return (await _videoLibraryServcies.Update(requestObject)) ? APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.BadRequest);

            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }

        [HttpDelete]
        public async Task<ResponseModel> DeleteVideoById(int id)
        {
            try
            {
                return (await _videoLibraryServcies.DeleteById(id)) > 0 ? APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.BadRequest);

            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }


        #endregion
    }
}

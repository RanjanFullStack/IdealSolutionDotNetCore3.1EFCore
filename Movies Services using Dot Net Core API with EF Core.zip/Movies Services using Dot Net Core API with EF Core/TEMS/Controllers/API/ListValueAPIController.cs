﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using TEMS.Services.Helpers;
using TEMS.Models.RequestModel;
using TEMS.Models.ResponseModel;
using System.Net.Http;
using System.Net.Http.Headers;
using TEMS.Models.Models;
using TEMS.Services.Interfaces;
using TEMS.BusinessLayer.Interfaces;

namespace TEMS.Controllers.API
{
    [Route("api/ListValue")]
    [ApiController]
    public class ListValueAPIController : ControllerBase
    {
        private IListValue _listValue;

        public ListValueAPIController(IListValue listValue)
        {
            _listValue = listValue;
        }
        #region StateInfo
        [HttpPost("GetAllSpecialtyList")]
        public async Task<ResponseModel> GetAllSpecialtyList()
        {
            try
            {
                var result = await _listValue.GetAllDetailListValue();
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {

                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }
        #endregion

    }

}

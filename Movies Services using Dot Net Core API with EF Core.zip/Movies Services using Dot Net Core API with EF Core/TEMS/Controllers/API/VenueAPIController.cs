﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TEMS.Services.Helpers;
using TEMS.Models.RequestModel;
using TEMS.Models.ResponseModel;
using System.Net.Http;
using System.Net.Http.Headers;
using TEMS.Models.Models;
using TEMS.Services.Interfaces;
namespace TEMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VenueAPIController : ControllerBase
    {
        private IVenue _venueInfo;
        public VenueAPIController( IVenue venueInfo)
        {
            _venueInfo = venueInfo;
        }
        #region VenueInfo

        [HttpPost("GetAllVenues")]
        public async Task<ResponseModel> GetAllVenues()
        {
            try
            {
                var result = await _venueInfo.GetAllVenues();
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {

                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }
        [HttpPost("GetVenue")]
        public async Task<ResponseModel> GetVenue([FromBody] int id) 
        {
            try
            {
                var result = await _venueInfo.GetVenueDetail(id);
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }

        [HttpPost("AddVenue")]
        public async Task<ResponseModel> AddVenue([FromBody] TblVenue requestObject)
        {
            try
            {

                return (await _venueInfo.AddVenue(requestObject)) ? APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.BadRequest);

            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }


        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TEMS.Services.Helpers;
using TEMS.Models.Hepler;
using TEMS.Models.Models;
using TEMS.Models.RequestModel;
using TEMS.Models.ResponseModel;
using TEMS.Services.Interfaces;

namespace TEMS.Controllers
{
    [Route("api/User")]
    [ApiController]
    public class UserAPIController : ControllerBase
    {
        private IUser _user;
        private IUserManage _userManage;

        public UserAPIController(IUser user, IUserManage userManage)
        {
            _user = user;
            _userManage = userManage;
        }

        [HttpPost("Register")]
        public async Task<ResponseModel> Register([FromBody]TblUser user)
        {
            try
            {
                int result = await _user.Add(user);
                return (result==1) ? APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.BadRequest);
            }
            catch (DuplicateRecordException du)
            {
                if (du.Message == "Email not available")
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.Conflict, "email_invalid", null);
                }
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.Conflict, du.Message);
            }
            catch (Exception ex)
            {
                return APIResponseObject.IsFailure(ex.Message);
            }
        }

        [HttpPost("Login")]
        public async Task<ResponseModel> Login([FromBody] LoginModel user)
        {
            try
            {
                TblUser userInformation = await _user.Login(user);
                return (userInformation == null) ? APIResponseObject.IsFailure(System.Net.HttpStatusCode.NotFound, "Invalid user", null) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK, "User logged in successfully", userInformation);
            }
            catch (Exception)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest, "BadRequest", null);
            }
        }
        [HttpPost("ResetPassword")]
        public async Task<ResponseModel> ResetPassword([FromBody] PasswordModel requestModel)
        {
            try
            {
                bool ResetPassword = await _user.ResetPassword(requestModel);
                return (ResetPassword) ? APIResponseObject.IsSuccess(): APIResponseObject.IsFailure(System.Net.HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                return APIResponseObject.IsFailure(ex.Message);
            }
        }
        [HttpPost("GetUserNameList")]
        public async Task<ResponseModel> GetUserNameList([FromBody] PasswordModel requestModel)
        {
            try
            {
                var result = await _userManage.GetAllUserName();
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }
        }
    }
}
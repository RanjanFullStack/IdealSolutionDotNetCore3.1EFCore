﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TEMS.Services.Helpers;
using TEMS.Models.RequestModel;
using TEMS.Models.ResponseModel;
using System.Net.Http;
using System.Net.Http.Headers;
using TEMS.Models.Models;
using TEMS.Services.Interfaces;
using TEMS.BusinessLayer.Interfaces;
using TEMS.Models.DataModel;
using TEMS.ViewModel;
using TEMS.Models.Hepler;
using System.Collections;

namespace TEMS.Controllers.API
{
    [Route("api/Practioner")]
    [ApiController]
    public class PractionerAPIController : ControllerBase
    {
        private IPractitioner _practitioner;

        public PractionerAPIController(IPractitioner practitioner)
        {
            _practitioner = practitioner;


        }
        [HttpPost("AddPractionerInfo")]
        public async Task<ResponseModel> AddPractionerInfo(PractitionerRequestModel practitionerRequestModel)
        {
            try
            {

                var result = await _practitioner.AddPractitioner(practitionerRequestModel);
                return (result == 1) ? APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.BadRequest);
            }
            catch (Exception e)
            {

                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }
    }
}

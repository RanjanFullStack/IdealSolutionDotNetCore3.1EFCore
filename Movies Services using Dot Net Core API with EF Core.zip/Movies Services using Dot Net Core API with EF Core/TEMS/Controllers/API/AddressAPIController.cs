﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TEMS.Services.Helpers;
using TEMS.Models.RequestModel;
using TEMS.Models.ResponseModel;
using System.Net.Http;
using System.Net.Http.Headers;
using TEMS.Models.Models;
using TEMS.Services.Interfaces;
using TEMS.BusinessLayer.Interfaces;
using TEMS.Models.DataModel;
using TEMS.ViewModel;
using TEMS.Models.Hepler;
using System.Collections;
using System;

namespace TEMS.Controllers.API
{
    [Route("api/Address")]
    [ApiController]
    public class AddressAPIController : ControllerBase
    {
        private IAddress _address;

        public AddressAPIController(IAddress address)
        {
            _address = address;


        }

        [HttpPost("AddPracticeInfo")]
        public async Task<ResponseModel> AddPracticeInfo(AddressRequestModel addressRequestModel)
        {
            try
            {
                bool result = await _address.AddAddress(addressRequestModel);
                return result ? APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.BadRequest);
            }
            catch (Exception e)

            {

                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.Conflict, "email_invalid", null);
            }

        }
    }
}

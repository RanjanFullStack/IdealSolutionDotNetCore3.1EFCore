﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using TEMS.Services.Helpers;
using TEMS.Models.RequestModel;
using TEMS.Models.ResponseModel;
using System.Net.Http;
using System.Net.Http.Headers;
using TEMS.Models.Models;
using TEMS.Services.Interfaces;
using TEMS.BusinessLayer.Interfaces;

namespace TEMS.Controllers
{
    /// <summary>
    /// This is an event api controller
    /// </summary>
    [Route("api/Event")]
    [ApiController]
    public class EventAPIController : ControllerBase
    {
        private IEvents _eventInfo;
        private IVenue _venueInfo;
        private IEventStatus _eventStatus;

        public EventAPIController(IEvents eventInfo, IVenue venueInfo)
        {
            _eventInfo = eventInfo;
            _venueInfo = venueInfo;
        }

        #region EventInfo
        [HttpPost("GetAllEvents")]
        public async Task<ResponseModel> GetAllEvents()
        {
            try
            {
                var result =await _eventInfo.GetAllEvents(); 
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {

                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }
        [HttpPost("GetEvent")]
        public async Task<ResponseModel> GetEvent([FromBody]BaseEventIdModel requestObject)
        {
            try
            {
                var result =await _eventInfo.GetEventDetail(requestObject);
                 return (result != null) ?
                    APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }
        [HttpPost("GetAllEventStatus")]
        public async Task<ResponseModel> GetEventStatus([FromBody] BaseEventIdModel requestObject)
        {
            try
            {
                var result = await _eventStatus.GetAllEventStatus();
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }
        [HttpPost("AddEvent")]
        public async Task<ResponseModel> AddEvent([FromBody]EventRequestModel requestObject)
        {
            try
            {

                return (await _eventInfo.AddEvent(requestObject)) ? APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.BadRequest); ;

            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }

        #endregion
        #region EventStatusInfo
        [HttpPost("GetAllEventStatus")]
        public async Task<ResponseModel> GetAllEventStatus()
        {
            try
            {
                var result = await _eventStatus.GetAllEventStatus();
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {

                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }
        #endregion

    }
}
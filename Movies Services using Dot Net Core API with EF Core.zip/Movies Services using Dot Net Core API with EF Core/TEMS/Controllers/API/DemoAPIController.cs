﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TEMS.Services.Helpers;
using TEMS.Models.RequestModel;
using TEMS.Models.ResponseModel;
using System.Net.Http;
using System.Net.Http.Headers;
using TEMS.Models.Models;
using TEMS.Services.Interfaces;
using TEMS.BusinessLayer.Interfaces;
using TEMS.ViewModel;

namespace TEMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DemoAPIController : ControllerBase
    {
        private IPractitioner _practitioner;
        private IUser _user;
        private IUserManage _userMange;
        private ITravelPreference _travelPreference;
        private IUserMealPreference _userMealPreference;
        private IUserHotelPreference _UserHotelPreference;
        public async Task<IActionResult> Post(ProfileViewModel profileViewModel)
        {
            try
            {
               PractitionerRequestModel practitionerRequest = profileViewModel.practitionerRequest;
                //PractitionerRequestModel practitionerRequestModel = new PractitionerRequestModel();
                var result = await _practitioner.AddPractitioner(practitionerRequest);
                //return (result != null) ?
                //   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {

                //return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }
            return Ok();
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using TEMS.Services.Helpers;
using TEMS.Models.RequestModel;
using TEMS.Models.ResponseModel;
using System.Net.Http;
using System.Net.Http.Headers;
using TEMS.Models.Models;
using TEMS.Services.Interfaces;
using TEMS.BusinessLayer.Interfaces;

namespace TEMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TimeZoneAPIController : ControllerBase
    {
        private ITimeZone _timeZone;

        [HttpPost("GetAllTimeZone(")]
        public async Task<ResponseModel> GetAllTimeZone()
        {
            try
            {
                var result = await _timeZone.GetAllTimeZone();
                return (result != null) ?
                   APIResponseObject.IsSuccess(result) : APIResponseObject.IsSuccess(System.Net.HttpStatusCode.NoContent, "No records found");
            }
            catch (Exception e)
            {

                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message, null);
            }

        }
    }
}

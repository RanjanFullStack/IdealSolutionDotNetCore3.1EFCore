﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TEMS.Models.EmailModel;
using TEMS.Models.ResponseModel;
using TEMS.Services.Helpers;

namespace TEMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailTemplateAPIController : ControllerBase
    {
        private IEmailTemplate _emailTemplate;
        public EmailTemplateAPIController(IEmailTemplate emailTemplate)
        {
            _emailTemplate = emailTemplate;
        }
        #region EmailTemplateDesign
        [HttpPost("GetAllEmailTemplate")]
        public async Task<ResponseModel> GetAllEmailTemplate()
        {
            try
            {
                var emailTemplate = await _emailTemplate.GetAllEmailTemplate();
                if (emailTemplate != null && emailTemplate.Count > 0)
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK, emailTemplate);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }

        [HttpPost("SaveEmailTemplate")]
        public async Task<ResponseModel> SaveEmailTemplate([FromBody] EmailRequestModel emailRequestModel)
        {
            try
            {
                if (await _emailTemplate.AddEmailTemplate(emailRequestModel))
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }

        [HttpPost("UpdateEmailTemplate")]
        public async Task<ResponseModel> UpdateEmailTemplate([FromBody] UpdateEmailRequestModel emailRequestModel)
        {
            try
            {
                if (await _emailTemplate.UpdateEmailTemplate(emailRequestModel))
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }

        [HttpPost("DeleteEmailTemplate")]
        public async Task<ResponseModel> DeleteEmailTemplate([FromBody] EmailBaseRequestModel emailRequestModel)
        {
            try
            {
                if (emailRequestModel.EmailId == Guid.Empty)
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest, "Email Id is required");
                }
                if (await _emailTemplate.DeleteEmailTemplate(emailRequestModel))
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }

        [HttpPost("GetEmailTemplate")]
        public async Task<ResponseModel> GetEmailTemplate([FromBody] EmailBaseRequestModel emailRequestModel)
        {
            try
            {
                if (emailRequestModel.EmailId == Guid.Empty)
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest, "Email Id is required");
                }
                var emailTemplate = await _emailTemplate.GetEmailTemplate(emailRequestModel);
                if (emailTemplate != null)
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK, emailTemplate);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }
        [HttpPost("CreateEmailTemplate")]
        public async Task<ResponseModel> CreateEmailTemplate()
        {
            try
            {
                if (await _emailTemplate.CreateEmailTemplate())
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }

        [HttpPost("GetEmailDetail")]
        public async Task<ResponseModel> GetEmailDetail([FromBody] EmailDetailRequestModel emailRequestModel)
        {
            try
            {
                var emailTemplate = await _emailTemplate.GetEmailDetail(emailRequestModel);
                if (emailTemplate != null)
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK, emailTemplate);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }

        #endregion

        #region EmailFooterDesign

        [HttpPost("GetEmailFooter")]
        public async Task<ResponseModel> GetEmailFooter([FromBody] EmailFooterRequestModel requestModel)
        {
            try
            {
                var emailFooter = await _emailTemplate.GetEmailFooter(requestModel);
                if (emailFooter != null)
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK, emailFooter);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }
        [HttpPost("SaveEmailFooter")]
        public async Task<ResponseModel> SaveEmailFooter()
        {
            try
            {
                if (await _emailTemplate.AddEmailFooter())
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }

        [HttpPost("UpdateEmailFooter")]
        public async Task<ResponseModel> UpdateEmailFooter([FromBody] EmailFooterModel emailRequestModel)
        {
            try
            {
                if (await _emailTemplate.UpdateEmailFooter(emailRequestModel))
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }
        #endregion

        #region EmailInformation

        [HttpPost("SaveEmailInformation")]
        public async Task<ResponseModel> SaveEmailInformation([FromBody] EmailInformation emailRequestModel)
        {
            try
            {
                if (await _emailTemplate.SaveEmailInformation(emailRequestModel))
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.Created);
                }
                else
                {
                    return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);
                }
            }
            catch (Exception e)
            {
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.InternalServerError, e.Message);
            }
        }

        #endregion

        #region ImageSave
        [HttpPost("SaveEndoLogoImage")]
        public async Task<ResponseModel> SaveEndoLogoImage(IFormFile endoLogolImage)
        {
            try
            {
                if(await _emailTemplate.SaveEndoLogoImage(endoLogolImage))
                {
                    return APIResponseObject.IsSuccess(System.Net.HttpStatusCode.OK);
                }
                return APIResponseObject.IsFailure(System.Net.HttpStatusCode.BadRequest);

            }
            catch (Exception ex)
            {
                return APIResponseObject.IsFailure(ex.Message);
            }
        }
        
        #endregion
    }
}

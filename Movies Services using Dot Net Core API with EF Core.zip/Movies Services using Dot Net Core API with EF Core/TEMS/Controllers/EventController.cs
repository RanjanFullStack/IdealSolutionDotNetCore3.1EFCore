﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TEMS.Models.Models;
using System.Web;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.Extensions.Options;
using TEMS.Models.ResponseModel;
using TEMS.Helpers;
using Microsoft.Extensions.Configuration;
using TEMS.ViewModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
namespace TEMS.Controllers
{
    public class EventController : Controller
    {
        private IConfiguration _configuration;
        private IOptions<Settings> _settings;
        private HTTPHelper _helper;
        private URLHelper _urlHelper;
        public EventController(IOptions<Settings> settings, IConfiguration configuration)
        {
            _settings = settings;
            _configuration = configuration;
            _helper = new HTTPHelper(_settings, _configuration);
            _urlHelper = new URLHelper(_settings);
        }

        public ActionResult Index()
        {
            Uri apiURL = _urlHelper.GetApiURL("Event", "GetAllEvents");
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();
            var requestURL = _helper.PostRequest(Client, apiURL);
            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            if (response.data == null)
            { 
                return View();
            }
            else
            {
                var events = JsonConvert.DeserializeObject<List<Event>>(Convert.ToString(response.data));
                return View(events);
            }
        }
       // [HttpGet]
        public IActionResult Events()
        {

            Uri apiURL = _urlHelper.GetApiURL("Event", "GetAllEvents");
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();    
            var requestURL = _helper.PostRequest(Client, apiURL);
            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            if (response.data == null)
            {
                return View();
            }
            else
            {
                var events = JsonConvert.DeserializeObject<List<Event>>(Convert.ToString(response.data));
                return View(events);

                //    var events = JsonConvert.DeserializeObject<List<MasterViewModel>>(Convert.ToString(response.data));
                //    return View(events);
                //IList<MasterViewModel> modelObj = JsonConvert.DeserializeObject<IList<MasterViewModel>>(response.data);
            }






            //#region State

            //Uri apiURLState = _urlHelper.GetApiURL("State", "GetAllStates");
            //_helper = new HTTPHelper(_settings, _configuration);
            //var ClientState = _helper.GetHttpClient();
            //var requestURLState = _helper.PostRequest(Client, apiURL);
            //var responseState = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            //if (response.data == null)
            //{
            //    return View();
            //}
            //else
            //{
            //    var StateList = JsonConvert.DeserializeObject<List<TblState>>(Convert.ToString(response.data));
            //    ViewData["StateList"] = StateList;
                
            //    //return View(StateList);
            //}

            //#endregion Status 


            //#region Status
            //Uri apiURLStatus = _urlHelper.GetApiURL("Event", "GetAllEventStatus");
            //_helper = new HTTPHelper(_settings, _configuration);
            //var ClientStatus = _helper.GetHttpClient();
            //var requestURLStatus = _helper.PostRequest(Client, apiURL);
            //var responseStatus = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            //if (response.data == null)
            //{
            //    return View();
            //}
            //else
            //{
            //    var StatusList = JsonConvert.DeserializeObject<List<TblEventStatus>>(Convert.ToString(response.data));
            //    // return View(events);
            //    ViewData["StatusList"] = StatusList;
            //}

            //#endregion


        }
        private void ConfigureViewModel(ViewModelMasterData model) 
        {



            //State

            IEnumerable<State> state = Repository.FetchStateList();
            model.StateList = new SelectList(state, "State_Name", "State_Name");

            //Status 

            IEnumerable<Status> statusList = Repository.FetchStatusList();
            model.statusList = new SelectList(statusList, "Status_Name", "Status_Name");
        }

        //public ActionResult EventsNew()
        //{
        //    //MasterTablePopUpData masterTablePopUpData = new MasterTablePopUpData();

        //    try
        //    {
        //        //UserAuthModel userContext = new UserAuthModel();
        //        //userContext = (UserAuthModel)HttpContext.Session["UserContext"];
        //        //if (userContext == null)
        //        //{
        //        //    return RedirectToAction("Login", "einvoiceclient", new { area = "" });
        //        //}
        //        using (HttpClient client = new HttpClient())
        //        {

        //            client.BaseAddress = new Uri(ConfigurationManager.AppSettings["Api_URL"]);
        //            client.DefaultRequestHeaders.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        //            HttpResponseMessage response = client.GetAsync("api/Event/GetAllEvents").Result;
        //            if (response.IsSuccessStatusCode)
        //            {
        //                var result = response.Content.ReadAsStringAsync().Result;
        //                masterTablePopUpData = JsonConvert.DeserializeObject<MasterTablePopUpData>(result);
        //            }
        //            else
        //            {
        //                masterTablePopUpData.ExceptionError = "Some issue to call API";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        masterTablePopUpData.ExceptionError = ex.Message;
        //    }
        //    return View(masterTablePopUpData);
        //}


        public ActionResult EventsDetails()
        {
            return View();
        }
        }
}
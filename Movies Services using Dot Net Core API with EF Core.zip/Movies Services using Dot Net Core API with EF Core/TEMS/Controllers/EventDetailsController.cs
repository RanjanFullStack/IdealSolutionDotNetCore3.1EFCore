﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;
using Microsoft.AspNetCore.Mvc.Rendering;
using TEMS.Models;
using TEMS.ViewModel;
using System.Net.Http;
using TEMS.Models.Models;
using System.Web;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.Extensions.Options;
using TEMS.Models.ResponseModel;
using TEMS.Helpers;
using Microsoft.Extensions.Configuration;
using System.ComponentModel.DataAnnotations;

namespace TEMS.Controllers
{
    public class EventDetailsController : Controller
    {
        private IConfiguration _configuration;
        private IOptions<Settings> _settings;
        private HTTPHelper _helper;
        private URLHelper _urlHelper;
        public EventDetailsController(IOptions<Settings> settings, IConfiguration configuration)
        {
            _settings = settings;
            _configuration = configuration;
            _helper = new HTTPHelper(_settings, _configuration);
            _urlHelper = new URLHelper(_settings);
        }
        public IActionResult Index()
        {
            return View();
        }
        
        [HttpGet]
        public IActionResult EventDetails()
        {

            ViewModelVenue VMMD = new ViewModelVenue();




            //#region topics
            //Uri apiURLTopic = _urlHelper.GetApiURL("Topic", "GetAllTopic");
            //_helper = new HTTPHelper(_settings, _configuration);
            //var Client = _helper.GetHttpClient();
            //var requestURL = _helper.PostRequest(Client, apiURLTopic);
            //var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            //if (response.data == null)
            //{
            //    return View();
            //}
            //else
            //{
            //    var Topic = JsonConvert.DeserializeObject<List<TblTopic>>(Convert.ToString(response.data));
            //    return View(Topic);

            //    //    var events = JsonConvert.DeserializeObject<List<MasterViewModel>>(Convert.ToString(response.data));
            //    //    return View(events);
            //    //IList<MasterViewModel> modelObj = JsonConvert.DeserializeObject<IList<MasterViewModel>>(response.data);
            //}
            //#endregion
            //#region TimeZone

            //Uri apiURLTime = _urlHelper.GetApiURL("TimeZone", "GetAllTimeZone");
            //_helper = new HTTPHelper(_settings, _configuration);
            //var ClientTime = _helper.GetHttpClient();
            //var requestURLTime = _helper.PostRequest(ClientTime, apiURLTime);
            //var responseTime = JsonConvert.DeserializeObject<ResponseModel>(requestURLTime.Result);
            //if (responseTime.data == null)
            //{
            //    return View();
            //}
            //else
            //{
            //    var TimeZone = JsonConvert.DeserializeObject<List<TblTimeZone>>(Convert.ToString(responseTime.data));
            //    return View(TimeZone);

            //    //    var events = JsonConvert.DeserializeObject<List<MasterViewModel>>(Convert.ToString(response.data));
            //    //    return View(events);
            //    //IList<MasterViewModel> modelObj = JsonConvert.DeserializeObject<IList<MasterViewModel>>(response.data);
            //}
            //#endregion
            //#region Representitive 

            //Uri apiURLUserName = _urlHelper.GetApiURL("TimeZone", "GetAllTimeZone");
            //_helper = new HTTPHelper(_settings, _configuration);
            //var ClientUserName = _helper.GetHttpClient();
            //var requestUserName = _helper.PostRequest(ClientUserName, apiURLTime);
            //var responseUserName = JsonConvert.DeserializeObject<ResponseModel>(requestUserName.Result);
            //if (responseUserName.data == null)
            //{
            //    return View();
            //}
            //else
            //{
            //    var UserName = JsonConvert.DeserializeObject<List<TblTimeZone>>(Convert.ToString(responseUserName.data));
            //    return View(UserName);

            //    //    var events = JsonConvert.DeserializeObject<List<MasterViewModel>>(Convert.ToString(response.data));
            //    //    return View(events);
            //    //IList<MasterViewModel> modelObj = JsonConvert.DeserializeObject<IList<MasterViewModel>>(response.data);
            //}
            //#endregion


            #region Events Details
            List<SelectListItem> topic = new List<SelectListItem>
        {
            new SelectListItem { Value = "1", Text = "Case Studies in Contact Lens Wear for Presbyopic Astigmats: Reframing the Discussion" },
            new SelectListItem { Value = "2", Text = "Contact Lenses For Presbyopic Astigmats: Changing the Conversation" },
            new SelectListItem { Value = "3", Text = "The Biotrue® ONEday Patient Experience"  },
            new SelectListItem { Value = "4", Text = "FIT Training"  },
            new SelectListItem { Value = "5", Text = "ACE - Management"  },
            new SelectListItem { Value = "6", Text = "ACE - Resident Meeting"  },
        };
            ViewBag.Topic = topic;

            List<SelectListItem> format = new List<SelectListItem>
        {
            new SelectListItem { Value = "1", Text = "Out of office" },
            new SelectListItem { Value = "2", Text = "In Office" },

        };
            ViewBag.Format = format;

            List<SelectListItem> timezone = new List<SelectListItem>
        {
            new SelectListItem { Value = "1", Text = "ET" },
            new SelectListItem { Value = "2", Text = "CT" },
            new SelectListItem { Value = "3", Text = "MT" },
            new SelectListItem { Value = "4", Text = "PT" },
            new SelectListItem { Value = "5", Text = "AKT" },
            new SelectListItem { Value = "6", Text = "HT" },
        };
            ViewBag.Timezone = timezone;


            List<SelectListItem> meetplanner = new List<SelectListItem>
        {
            new SelectListItem { Value = "1", Text = "Yolanda Anderson" },
            new SelectListItem { Value = "2", Text = "Chris Axt" },
            new SelectListItem { Value = "3", Text = "Ryan Baskwell" },
            new SelectListItem { Value = "4", Text = "Lilia Brekke" },
            new SelectListItem { Value = "5", Text = "Kevin Conroy" },
            new SelectListItem { Value = "6", Text = "Kelly Curia-Schmidt" },
        };
            ViewBag.Meetinigplanner = meetplanner;

            List<SelectListItem> salerep = new List<SelectListItem>
        {
            new SelectListItem { Value = "1", Text = "Bill O'Bryon" },
            new SelectListItem { Value = "2", Text = "Jennifer Reilly" },
            new SelectListItem { Value = "3", Text = "Ryan Baskwell" },
            new SelectListItem { Value = "4", Text = "Kristen Scannell" },
            new SelectListItem { Value = "5", Text = "Kevin Conroy" },
            new SelectListItem { Value = "6", Text = "Kelly Curia-Schmidt" },
        };
            ViewBag.SalesRep = salerep;

            List<SelectListItem> salerep1 = new List<SelectListItem>
        {
            new SelectListItem { Value = "1", Text = "Bill O'Bryon" },
            new SelectListItem { Value = "2", Text = "Jennifer Reilly" },
            new SelectListItem { Value = "3", Text = "Ryan Baskwell" },
            new SelectListItem { Value = "4", Text = "Kristen Scannell" },
            new SelectListItem { Value = "5", Text = "Kevin Conroy" },
            new SelectListItem { Value = "6", Text = "Kelly Curia-Schmidt" },
        };
            ViewBag.SalesRepadditional = salerep1;


            Eventdetail rec = new Eventdetail

            {
                Id = 101,
                SpeakerName = "John",
                RepName = "Mitchel",
                EventStatus = "Approved",
                EventDescription = "City Fish Market – Boca Raton, Florida",
                Topic = "Case study in contact Lens wear",
                Noattend = 15,
                Format = "Out of Office",
                startdate = "29-05-2020",
                Enddate = "30-05-2020",
                Starttime = "10:00 AM",
                Timezone = "ET",
                Eventloc = "Florida",
                Eventvenue = "Boca Raton",
                SalesRep = "Mitchel",
                EndoFname = "John",
                EndoLname = "A",
                EndoEmail = "abcd@gmail.com",
                EndoPhone = 01234568,
                Trainer = "Brain",
                Territoryid = 20,
                EverFname = "Michal ",
                EverLname = "waugh",
                EverEmail = "m@eversanna.com",
                EverPhone = 01468752,
                Capacity = 200
            };
            ViewBag.Message = rec;
            #endregion

            #region Speaker
            //Speaker
            #endregion 
            #region Venue
            ConfigureViewModel(VMMD);
            VMMD.VenueList = GetVenueRecords();
            #endregion
            #region Attendees
            List<Attendees> objEvent = new List<Attendees>()
           {
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "0001293446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "0001393446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "0001493446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "0001593446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "0001693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "0001793446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "0001893446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "0001993446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "0002093446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Speaker ", Degree ="OD",NPI = "1487693446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},
               new Attendees{Status = "Confirmed", FirstName = "Jhon", MiddleName = "Thommas",LastName = "Womack", Role = "Rep ", Degree ="OD",NPI = "0001293446",Optout = "",STATE = "New York",Registration = "Added", Date_Registration = "01/04/2020", Signature ="",Profession_Function = "Optometrist",Title = "",Affiliation = "Optometrist",Address = "4413 Towncenter Parkway ", Address2 ="",Email = "jwomackod24@gmail.com",Zip = "32246",Country = "United States",Phone = "904 998 9871", State_License = "FL", StateLicenseNubmer ="4081",MealRequirements = "",Allergies = "",City="Jacksonville"},

           };
            ViewData["Data"] = objEvent;
            #endregion




            return View(VMMD);
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public IActionResult EventDetails(ViewModelVenue VMM)
        //{
        //    if (ModelState.IsValid)
        //    {

        //        Venue venue = new Venue();

        //        VMM.City = venue.City;
        //    }
        //    return View(VMM);
        //}


        #region 


        private List<Venue> GetVenueRecords()
        {
            var listEvents = new List<Venue>();
            List<Venue> obj_EventList = new List<Venue>()
           {
               new Venue{Venue_ID = 10001, Venue_Name  = "Abe Louise's", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Chicago ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "7064043216",Contact = "jwomackod24@gmail.com",Cell  = "12345"},
               new Venue{Venue_ID = 10001, Venue_Name  = "Clinton", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Phonex ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "8888888888",Contact = "srbsahoo@gmail.com",Cell  = "12345"},
               new Venue{Venue_ID = 10001, Venue_Name  = "Abe Louise's", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Huston ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "1234567890",Contact = "jwomackod24@gmail.com",Cell  = "12345"},
               new Venue{Venue_ID = 10001, Venue_Name  = "Abe Louise's", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Chicago ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "9999999999",Contact = "jwomackod24@gmail.com",Cell  = "12345"},
               new Venue{Venue_ID = 10001, Venue_Name  = "Abe Louise's", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Chicago ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "7064043216",Contact = "jwomackod24@gmail.com",Cell  = "12345"},
               new Venue{Venue_ID = 10001, Venue_Name  = "Abe Louise's", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Chicago ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "7064043216",Contact = "jwomackod24@gmail.com",Cell  = "12345"},
               new Venue{Venue_ID = 10001, Venue_Name  = "Abe Louise's", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Chicago ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "7064043216",Contact = "jwomackod24@gmail.com",Cell  = "12345"},
               new Venue{Venue_ID = 10001, Venue_Name  = "Abe Louise's", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Chicago ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "7064043216",Contact = "jwomackod24@gmail.com",Cell  = "12345"},
               new Venue{Venue_ID = 10001, Venue_Name  = "Abe Louise's", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Chicago ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "7064043216",Contact = "jwomackod24@gmail.com",Cell  = "12345"},
               new Venue{Venue_ID = 10001, Venue_Name  = "Abe Louise's", Address_1 = "Bosten,01",Address_2 = "Bosten,02", City = "Chicago ",STATE = "Lllinoise",Email = "jwomackod24@gmail.com",Zip = "32246",Additional_Comments = "New York",Phone  = "7064043216",Contact = "jwomackod24@gmail.com",Cell  = "12345"},

           };

            return obj_EventList;

        }



        private void ConfigureViewModel(ViewModelVenue VMM)
        {



            //State

            IEnumerable<State> state = Repository.FetchStateList();
            VMM.StateList = new SelectList(state, "State_Name", "State_Name");


        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using TEMS.Models.Models;
using System.Web;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.Extensions.Options;
using TEMS.Models.ResponseModel;
using TEMS.Helpers;
using Microsoft.Extensions.Configuration;
using TEMS.ViewModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using TEMS.Models.RequestModel;

namespace TEMS.Controllers
{
    public class AccountController : Controller
    {
        static bool AnchorStatus = false;
        private IConfiguration _configuration;
        private IOptions<Settings> _settings;
        private HTTPHelper _helper;
        private URLHelper _urlHelper;
        public AccountController(IOptions<Settings> settings, IConfiguration configuration)
        {
            _settings = settings;
            _configuration = configuration;
            _helper = new HTTPHelper(_settings, _configuration);
            _urlHelper = new URLHelper(_settings);
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult createaccount()
        {
            AnchorStatus = false;
            ViewBag.AnchorStatus = AnchorStatus;
            return View();
        } 
        [HttpPost]
        public IActionResult createaccount(TblUser user)
        {
            Uri apiURL = _urlHelper.GetApiURL("User", "Register");
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();
            var requestURL = _helper.PostRequest(Client, apiURL);
            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            if (response.data == null)
            {
                return View();
            }
            else
            {
                var users = JsonConvert.DeserializeObject<List<TblUser>>(Convert.ToString(response.data));
                return View(users);
            }
        }




        public IActionResult Welcome()
        {

            return View();
        }

        public IActionResult forgetpassword()
        {
            AnchorStatus = true;
            ViewBag.AnchorStatus = AnchorStatus;

            return View();
        }
        [HttpGet]

        public IActionResult login()
        {
            AnchorStatus = true;
            ViewBag.AnchorStatus = AnchorStatus;
            return View();
        }
        [HttpPost]
        public IActionResult login(LoginModel loginModel)
        {
            Uri apiURL = _urlHelper.GetApiURL("User", "Login");
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();
            var requestURL = _helper.PostRequest(Client, apiURL);
            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            if (response.data == null)
            {
                return View();
            }
            else
            {
                var users = JsonConvert.DeserializeObject<List<TblUser>>(Convert.ToString(response.data));
                return View(users);
            }
        }
        [HttpGet]
        public IActionResult Resetpassword()
        {
            AnchorStatus = true;
            ViewBag.AnchorStatus = AnchorStatus;
            return View();
        }
        [HttpPost]
        public IActionResult Resetpassword(PasswordModel passwordModel)
        {
            Uri apiURL = _urlHelper.GetApiURL("User", "ResetPassword");
            _helper = new HTTPHelper(_settings, _configuration);
            var Client = _helper.GetHttpClient();
            var requestURL = _helper.PostRequest(Client, apiURL);
            var response = JsonConvert.DeserializeObject<ResponseModel>(requestURL.Result);
            if (response.data == null)
            {
                return View();
            }
            else
            {
                var users = JsonConvert.DeserializeObject<List<TblUser>>(Convert.ToString(response.data));
                return View(users);
            }
        }
        public IActionResult ContactUs()
        {
            
            return View();
        } 
       
    }
}
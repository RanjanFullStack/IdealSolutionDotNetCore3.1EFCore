import { videoLibrary } from './videoLibrary';

describe('videoLibrary', () => {
  it('should create an instance', () => {
    //expect(new videoLibrary()).toBeTruthy();
  });
});

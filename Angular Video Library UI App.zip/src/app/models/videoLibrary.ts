export class video {
  id: number;
  title: string;
  releaseYear?: number;
  locations: string;
  funFacts: string;
  productionCompany: string;
  distributor: string;
  director: string;
  writer: string;
  actor1: string;
  actor2: string;
  actor3: string;
}

export class videoLibrary {
  isSuccess: boolean;
  httpStatusCode: number;
  message?: any;
  data: video[];
}

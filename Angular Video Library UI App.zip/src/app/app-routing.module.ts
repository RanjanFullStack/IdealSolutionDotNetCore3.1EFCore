// app-routing.module.ts
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { videoLibraryComponent } from './pages/videoLibrary/videoLibrary.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: '/videoLibrary',
    pathMatch: 'full'
  },
  {
    path: 'videoLibrary',
    component: videoLibraryComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

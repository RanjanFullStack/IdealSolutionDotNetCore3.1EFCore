import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { video } from './models/videoLibrary';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'VideoLibrary';
  dataSource = new MatTableDataSource<video>();

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}

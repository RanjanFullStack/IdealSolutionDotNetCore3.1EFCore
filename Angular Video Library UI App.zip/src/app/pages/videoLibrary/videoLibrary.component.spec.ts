import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { videoLibraryComponent } from './videoLibrary.component';

describe('videoLibraryComponent', () => {
  let component: videoLibraryComponent;
  let fixture: ComponentFixture<videoLibraryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ videoLibraryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(videoLibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

// videoLibrary.component.ts
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { HttpDataService } from 'src/app/services/http-data.service';
import * as _ from 'lodash';
import { NgForm } from '@angular/forms';
import { video } from 'src/app/models/videoLibrary';

@Component({
  selector: 'app-videoLibrary',
  templateUrl: './videoLibrary.component.html',
  styleUrls: ['./videoLibrary.component.css']
})
export class videoLibraryComponent implements OnInit {

  filterVideo(video: video) {
    return video.title
  }

  @ViewChild('videoLibraryForm', { static: false })
  videoLibraryForm: NgForm;

  videoLibraryData: video;

  dataSource = new MatTableDataSource();
  displayedColumns: string[] = ['title', 'releaseYear', 'locations', 'funFacts', 'productionCompany','distributor', 'director', 'writer', 'actor1', 'actor2','actor3'];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  isEditMode = false;

  constructor(private httpDataService: HttpDataService) {
    this.videoLibraryData = {} as video;
  }

  ngOnInit(): void {

    // Initializing Datatable pagination
    this.dataSource.paginator = this.paginator;

    // Fetch All videoLibrary on Page load
    this.getAllvideoLibrary()
  }

  getAllvideoLibrary() {
    this.httpDataService.getList().subscribe((response: any) => {
      this.dataSource.data = response.data;
    });
  }

  editItem(element) {
    this.videoLibraryData = _.cloneDeep(element);
    this.isEditMode = true;
  }

  cancelEdit() {
    this.isEditMode = false;
    this.videoLibraryForm.resetForm();
  }

  deleteItem(id) {
    this.httpDataService.deleteItem(id).subscribe((response: any) => {

      // Approach #1 to update datatable data on local itself without fetching new data from server
      this.dataSource.data = this.dataSource.data.filter((o: video) => {
        return o.id !== id ? o : false;
      })

      console.log(this.dataSource.data);

      // Approach #2 to re-call getAllvideoLibrary() to fetch updated data
      // this.getAllvideoLibrary()
    });
  }

  addvideoLibrary() {
    this.httpDataService.createItem(this.videoLibraryData).subscribe((response: any) => {
      this.dataSource.data.push({ ...response })
      this.dataSource.data = this.dataSource.data.map(o => {
        return o;
      })
    });
  }

  updatevideoLibrary() {
    this.httpDataService.updateItem(this.videoLibraryData.id, this.videoLibraryData).subscribe((response: any) => {

      // Approach #1 to update datatable data on local itself without fetching new data from server
      this.dataSource.data = this.dataSource.data.map((o: video) => {
        if (o.id === response.id) {
          o = response;
        }
        return o;
      })

      // Approach #2 to re-call getAllvideoLibrary() to fetch updated data
      // this.getAllvideoLibrary()

      this.cancelEdit()

    });
  }


  onSubmit() {
    if (this.videoLibraryForm.form.valid) {
      if (this.isEditMode)
        this.updatevideoLibrary()
      else
        this.addvideoLibrary();
    } else {
      console.log('Enter valid data!');
    }
  }
}
